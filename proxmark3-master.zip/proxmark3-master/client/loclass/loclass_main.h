#ifndef LOCLASS_MAIN_H
#define LOCLASS_MAIN_H

#endif // LOCLASS_MAIN_H
