// Low frequency Kantech commands
//-----------------------------------------------------------------------------

#ifndef CMDLFIO_H__
#define CMDLFIO_H__

int CmdLFIO(const char *Cmd);

int CmdIODemodFSK(const char *Cmd);

#endif
