These files are downloaded from here: http://cq.cx/proxmark3.pl

These are the original, non-modified parts. 

What I've noticed that there are problems with the stop mask layers (via and component silkscreen print) This is what I'm going to modify in my cad / cam version.